Recon-Hawk - OSINT Web Scanner by kader11000
---------------------------------------------

1. تأكد من تثبيت الأدوات التالية:
   pip install flask python-whois dnspython
   sudo apt install sublist3r theharvester

2. لتشغيل التطبيق:
   python recon_hawk_webapp.py

3. افتح المتصفح على:
   http://127.0.0.1:5000

4. كلمة المرور للواجهة:
   kader11000

---------------------------------------------