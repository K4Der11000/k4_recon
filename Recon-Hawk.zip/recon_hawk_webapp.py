from flask import Flask, render_template, request, redirect, url_for, session
import whois
import dns.resolver
import subprocess
import re
import os

app = Flask(__name__, template_folder='templates', static_folder='static')
app.secret_key = 'supersecretkey123'  # يجب تغييره في الإنتاج
PASSWORD = "kader11000"

def get_whois_info(domain):
    try:
        w = whois.whois(domain)
        return {
            'registrar': w.registrar,
            'emails': w.emails,
            'country': w.country
        }
    except:
        return {'error': 'WHOIS lookup failed.'}

def discover_subdomains(domain):
    try:
        output = subprocess.check_output(["sublist3r", "-d", domain], stderr=subprocess.DEVNULL)
        subs = re.findall(r'([a-zA-Z0-9_-]+\.' + re.escape(domain) + r')', output.decode())
        return list(set(subs))
    except:
        return []

def resolve_ips(subdomains):
    resolved = []
    for sub in subdomains:
        try:
            ip = dns.resolver.resolve(sub, 'A')[0].to_text()
            resolved.append({'subdomain': sub, 'ip': ip})
        except:
            resolved.append({'subdomain': sub, 'ip': 'N/A'})
    return resolved

def extract_emails(domain):
    try:
        result = subprocess.check_output(["theHarvester", "-d", domain, "-b", "bing"], stderr=subprocess.DEVNULL)
        emails = re.findall(r'[\w\.-]+@[\w\.-]+', result.decode())
        return list(set(emails))
    except:
        return []

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        password = request.form['password']
        if password == PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('index'))
    return render_template('login.html')

@app.route('/scan', methods=['GET', 'POST'])
def index():
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    data = {}
    if request.method == 'POST':
        domain = request.form['domain']
        data['domain'] = domain
        data['whois'] = get_whois_info(domain)
        subs = discover_subdomains(domain)
        data['subdomains'] = resolve_ips(subs)
        data['emails'] = extract_emails(domain)
    return render_template('index.html', data=data)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)